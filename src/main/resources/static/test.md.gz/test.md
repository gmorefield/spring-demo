# Spring Demo

Sample application to demonstrate some of the features of Spring Boot
]